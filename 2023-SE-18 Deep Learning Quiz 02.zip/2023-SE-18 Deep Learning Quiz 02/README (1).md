# Bill / Receipt Detection using SAM (Segment Anything)

This project detects **individual bills (receipts)** in a single image where several bills are placed together like a collage. Each detected bill gets a colored **border** and a label (`Bill 1`, `Bill 2`, ...). Nothing is filled inside the bill; only the border and the label are drawn.

## Files

| File | Purpose |
|------|---------|
| `Quiz_of_Deep_Learning.ipynb` | Main Google Colab notebook (all the code) |
| `README.md` | This file |
| Input image (`.jpeg`) | The collage of bills, uploaded at runtime |
| `bills_detected.jpg` | Output image (created after the notebook runs) |

## Requirements

- Google Colab (recommended)
- Python packages (installed automatically by the notebook):
  - `ultralytics` (for the SAM model)
  - `opencv-python`
  - `numpy`

## How to Run

1. Open `Quiz_of_Deep_Learning.ipynb` in Google Colab.
2. Run the cells in order, from top to bottom.
3. When the first cell shows **Choose Files**, upload your input image containing the bills.
4. After the last cell finishes, `bills_detected.jpg` is displayed in the notebook and downloaded automatically.

## How the Code Works

1. **Install and upload:** the libraries are installed and the image is loaded with `cv2.imread`.
2. **SAM segmentation:** the `sam_b.pt` model runs in "segment everything" mode and returns a mask (polygon) for every object in the image. The weights are downloaded automatically the first time.
3. **Filtering candidate masks:**
   - Masks that are too small or too large are rejected (`0.04 < area ratio < 0.35`).
   - Only masks that look like a rectangle (`rectangularity > 0.85`) and are elongated (`aspect > 1.3`) are kept, since a bill is usually a long rectangle.
4. **Removing duplicates:** if a mask lies mostly (more than 50%) inside a larger mask that was already kept, it is discarded.
5. **Text density filter:** blank or faded paper regions are removed. Only masks with enough dark (text) pixels are kept (`text_ratio > 0.01`).
6. **Drawing the result:** for each bill, a border is drawn using `minAreaRect` and `cv2.polylines` (thick line), and `Bill N` is written near the top-left corner. There is no color fill inside the border.

## Tuning (if the result is not right)

| Problem | What to change |
|---------|----------------|
| A bill is missed | Widen the `0.04 < ratio < 0.35` range, or lower the `rectangularity` / `aspect` thresholds |
| Extra, unwanted masks appear | Increase `text_ratio > 0.01` (for example to `0.02`) |
| Border too thin or too thick | Change the last number in `cv2.polylines(..., 6)` |
| Label size | Change the font scale (`1.2`) and thickness (`3`) in `cv2.putText` |

## Notes

- The old outputs in the notebook were cleared. Run the notebook again to see the new result.
- The comments inside the notebook code are written in Roman Urdu.
